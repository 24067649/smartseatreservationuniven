/*
  RLS FIX for UNIVEN Library
  Problem: admin cannot see other users bookings/profiles because
  the original RLS policies self-reference public.profiles which
  causes silent recursion -> no rows returned.
  Fix: SECURITY DEFINER helper that bypasses RLS for the role check.
  Safe to run multiple times. Paste into Supabase SQL Editor and run.
*/

create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce(
    (select role from public.profiles where id = auth.uid()),
    'student'
  ) = 'admin'
$$;

grant execute on function public.is_admin() to authenticated, anon;

-- Profiles policies - FULL ADMIN ACCESS + own profile
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select
  using (auth.uid() = id or public.is_admin());

-- NEW: Allow admins to INSERT new profiles (create users)
drop policy if exists "profiles_insert_admin" on public.profiles;
create policy "profiles_insert_admin" on public.profiles for insert
  with check (public.is_admin());

-- NEW: Allow admins to UPDATE any profiles
drop policy if exists "profiles_update_admin" on public.profiles;
create policy "profiles_update_admin" on public.profiles for update
  using (public.is_admin())
  with check (public.is_admin());

-- NEW: Allow admins to DELETE any profiles
drop policy if exists "profiles_delete_admin" on public.profiles;
create policy "profiles_delete_admin" on public.profiles for delete
  using (public.is_admin());

drop policy if exists "zones_write_admin" on public.zones;
create policy "zones_write_admin" on public.zones for all
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "seats_write_admin" on public.seats;
create policy "seats_write_admin" on public.seats for all
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "bookings_select" on public.bookings;
create policy "bookings_select" on public.bookings for select
  using (auth.uid() = user_id or public.is_admin());

drop policy if exists "bookings_update" on public.bookings;
create policy "bookings_update" on public.bookings for update
  using (auth.uid() = user_id or public.is_admin())
  with check (auth.uid() = user_id or public.is_admin());

-- NEW: Ensure proper grants for profile management
grant insert, update, delete on public.profiles to authenticated;

do $$
begin
  begin
    alter publication supabase_realtime add table public.bookings;
  exception when duplicate_object then null; end;
  begin
    alter publication supabase_realtime add table public.zones;
  exception when duplicate_object then null; end;
  begin
    alter publication supabase_realtime add table public.seats;
  exception when duplicate_object then null; end;
end $$;