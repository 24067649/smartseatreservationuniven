-- ============================================================
--  UNIVEN Library — FIXED Schema (run in Supabase SQL Editor)
--  Key Fix: Admins can now INSERT/UPDATE all profiles
-- ============================================================

-- ── EXTENSIONS ───────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── TABLES ───────────────────────────────────────────────────
create table if not exists public.profiles (
  id             uuid primary key references auth.users(id) on delete cascade,
  full_name      text not null default '',
  student_number text,
  email          text,
  role           text not null default 'student' check (role in ('student','admin')),
  created_at     timestamptz default now()
);

create table if not exists public.zones (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  label       text not null,
  total_seats int  not null default 20,
  floor       int  not null default 1,
  color       text default '#c9a84c',
  is_active   boolean default true,
  created_at  timestamptz default now()
);

create table if not exists public.seats (
  id          uuid primary key default uuid_generate_v4(),
  zone_id     uuid not null references public.zones(id) on delete cascade,
  seat_number int  not null,
  unique(zone_id, seat_number)
);

create table if not exists public.bookings (
  id             uuid primary key default uuid_generate_v4(),
  user_id        uuid not null references auth.users(id) on delete cascade,
  seat_id        uuid not null references public.seats(id) on delete cascade,
  booking_date   date not null,
  start_time     time not null,
  duration_hours int  not null default 2,
  status         text not null default 'pending'
                 check (status in ('pending','approved','rejected','cancelled','completed')),
  student_number text,
  admin_note     text,
  reviewed_by    uuid references auth.users(id),
  reviewed_at    timestamptz,
  created_at     timestamptz default now()
);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────
alter table public.profiles enable row level security;
alter table public.zones     enable row level security;
alter table public.seats     enable row level security;
alter table public.bookings  enable row level security;

-- Helper: is the current user an admin?
create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce(
    (select role from public.profiles where id = auth.uid()),
    'student'
  ) = 'admin'
$$;
grant execute on function public.is_admin() to authenticated, anon;

-- ── FIXED PROFILES POLICIES ───────────────────────────────────
-- Drop all existing policies first
drop policy if exists "profiles_select_own"  on public.profiles;
drop policy if exists "profiles_insert_own"  on public.profiles;
drop policy if exists "profiles_update_own"  on public.profiles;
drop policy if exists "Users can create own profile" on public.profiles;
drop policy if exists "Users can view own profile" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Service role can manage profiles" on public.profiles;

-- ✅ FIXED: Users can read their own profile OR admin sees all
create policy "profiles_select" on public.profiles for select
  using (auth.uid() = id or public.is_admin());

-- ✅ FIXED: Users can insert their own OR admin can insert any
create policy "profiles_insert" on public.profiles for insert
  with check (auth.uid() = id or public.is_admin());

-- ✅ FIXED: Users can update their own OR admin can update any
create policy "profiles_update" on public.profiles for update
  using (auth.uid() = id or public.is_admin())
  with check (auth.uid() = id or public.is_admin());

-- Zones: everyone reads, admins write
drop policy if exists "zones_select_all"   on public.zones;
drop policy if exists "zones_write_admin"  on public.zones;
create policy "zones_select_all"  on public.zones for select using (true);
create policy "zones_write_admin" on public.zones for all
  using (public.is_admin())
  with check (public.is_admin());

-- Seats: everyone reads, admins write
drop policy if exists "seats_select_all"  on public.seats;
drop policy if exists "seats_write_admin" on public.seats;
create policy "seats_select_all"  on public.seats for select using (true);
create policy "seats_write_admin" on public.seats for all
  using (public.is_admin())
  with check (public.is_admin());

-- Bookings: own rows + admin sees everything
drop policy if exists "bookings_select"  on public.bookings;
drop policy if exists "bookings_insert"  on public.bookings;
drop policy if exists "bookings_update"  on public.bookings;
create policy "bookings_select" on public.bookings for select
  using (auth.uid() = user_id or public.is_admin());
create policy "bookings_insert" on public.bookings for insert
  with check (auth.uid() = user_id);
create policy "bookings_update" on public.bookings for update
  using (auth.uid() = user_id or public.is_admin())
  with check (auth.uid() = user_id or public.is_admin());

-- ── REALTIME ─────────────────────────────────────────────────
alter publication supabase_realtime add table public.bookings;
alter publication supabase_realtime add table public.zones;
alter publication supabase_realtime add table public.seats;

-- ── AUTO-CREATE PROFILE ON SIGNUP ────────────────────────────
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name, student_number, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
    new.raw_user_meta_data->>'student_number',
    new.email,
    'student'
  ) on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ── SEED ZONES ───────────────────────────────────────────────
insert into public.zones (name, label, total_seats, floor, color) values
  ('Zone A', 'Quiet Study',   20, 1, '#c9a84c'),
  ('Zone B', 'Group Study',   16, 1, '#2dd4bf'),
  ('Zone C', 'Computer Lab',  24, 2, '#818cf8'),
  ('Zone D', 'Reading Room',  18, 2, '#f97316'),
  ('Zone E', 'Postgraduate',  12, 3, '#ec4899'),
  ('Zone F', 'Open Floor',    10, 3, '#22c55e')
on conflict do nothing;

-- ── SEED SEATS ───────────────────────────────────────────────
insert into public.seats (zone_id, seat_number)
select z.id, n
from public.zones z
cross join generate_series(1, z.total_seats) as n
on conflict do nothing;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS profiles_id_idx ON public.profiles (id);
CREATE INDEX IF NOT EXISTS profiles_role_idx ON public.profiles (role);