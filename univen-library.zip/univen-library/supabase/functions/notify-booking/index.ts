// ============================================================
//  Supabase Edge Function: notify-booking
//  Sends emails when bookings are created, approved, or rejected
//
//  Deploy with:
//    supabase functions deploy notify-booking
//
//  Set env vars in Supabase Dashboard → Edge Functions → Secrets:
//    RESEND_API_KEY  =  your key from resend.com (free tier = 3000 emails/month)
//    ADMIN_EMAIL     =  admin@yourdomain.com
// ============================================================

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") ?? "";
const ADMIN_EMAIL    = Deno.env.get("ADMIN_EMAIL") ?? "";
const FROM_EMAIL     = "UNIVEN Library <noreply@yourdomain.com>";

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const { type, booking } = await req.json();
  // type: "new_request" | "approved" | "rejected"

  let to: string, subject: string, html: string;

  if (type === "new_request") {
    // Notify admin of new booking request
    to      = ADMIN_EMAIL;
    subject = `New seat request from ${booking.student_name}`;
    html    = `
      <h2 style="font-family:sans-serif;color:#111">New Seat Request</h2>
      <p style="font-family:sans-serif;color:#444">A student has requested a seat in the UNIVEN Library.</p>
      <table style="font-family:sans-serif;border-collapse:collapse;width:100%;max-width:480px">
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Student</td><td style="padding:8px 0;font-size:14px"><strong>${booking.student_name}</strong></td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Student No.</td><td style="padding:8px 0;font-size:14px">${booking.student_number || "–"}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Zone</td><td style="padding:8px 0;font-size:14px">${booking.zone_name}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Seat</td><td style="padding:8px 0;font-size:14px">Seat ${booking.seat_number}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Date</td><td style="padding:8px 0;font-size:14px">${booking.booking_date}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Time</td><td style="padding:8px 0;font-size:14px">${booking.start_time} · ${booking.duration_hours} hour(s)</td></tr>
      </table>
      <p style="font-family:sans-serif;margin-top:24px">
        <a href="${booking.admin_url}" style="background:#c9a84c;color:#000;padding:12px 24px;text-decoration:none;border-radius:6px;font-weight:bold;font-family:sans-serif">
          Review Request
        </a>
      </p>
    `;
  } else if (type === "approved") {
    // Notify student their booking was approved
    to      = booking.student_email;
    subject = `✓ Your seat request has been approved`;
    html    = `
      <h2 style="font-family:sans-serif;color:#111">Booking Approved!</h2>
      <p style="font-family:sans-serif;color:#444">Hi ${booking.student_name}, your seat request has been approved by the library admin.</p>
      <table style="font-family:sans-serif;border-collapse:collapse;width:100%;max-width:480px">
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Zone</td><td style="padding:8px 0;font-size:14px"><strong>${booking.zone_name}</strong></td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Seat</td><td style="padding:8px 0;font-size:14px">Seat ${booking.seat_number}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Date</td><td style="padding:8px 0;font-size:14px">${booking.booking_date}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Time</td><td style="padding:8px 0;font-size:14px">${booking.start_time} · ${booking.duration_hours} hour(s)</td></tr>
      </table>
      <p style="font-family:sans-serif;color:#22c55e;font-weight:bold;margin-top:16px">Please arrive on time. Enjoy your study session!</p>
    `;
  } else if (type === "rejected") {
    // Notify student their booking was rejected
    to      = booking.student_email;
    subject = `Your seat request was not approved`;
    html    = `
      <h2 style="font-family:sans-serif;color:#111">Booking Not Approved</h2>
      <p style="font-family:sans-serif;color:#444">Hi ${booking.student_name}, unfortunately your seat request could not be approved.</p>
      <table style="font-family:sans-serif;border-collapse:collapse;width:100%;max-width:480px">
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Zone</td><td style="padding:8px 0;font-size:14px">${booking.zone_name}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Seat</td><td style="padding:8px 0;font-size:14px">Seat ${booking.seat_number}</td></tr>
        <tr><td style="padding:8px 0;color:#888;font-size:14px">Date</td><td style="padding:8px 0;font-size:14px">${booking.booking_date}</td></tr>
        ${booking.admin_note ? `<tr><td style="padding:8px 0;color:#888;font-size:14px">Reason</td><td style="padding:8px 0;font-size:14px;color:#ef4444">${booking.admin_note}</td></tr>` : ""}
      </table>
      <p style="font-family:sans-serif;color:#444;margin-top:16px">You may submit a new request for a different seat or date.</p>
    `;
  } else {
    return new Response(JSON.stringify({ error: "Unknown type" }), { status: 400 });
  }

  // Send via Resend
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, html }),
  });

  const data = await res.json();
  return new Response(JSON.stringify(data), {
    status: res.status,
    headers: { "Content-Type": "application/json" },
  });
});
