// ============================================================
//  utils.js — shared helpers used by all pages
// ============================================================
import { SUPABASE_URL, SUPABASE_ANON } from './config.js';

const { createClient } = window.supabase;

// Single shared Supabase client
export const sb = createClient(SUPABASE_URL, SUPABASE_ANON);

// ── DATE HELPERS ─────────────────────────────────────────────
export const todayStr = () => new Date().toISOString().split('T')[0];

export function addDays(dateStr, n) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + n);
  return d.toISOString().split('T')[0];
}

export function formatDateFriendly(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  const today = todayStr();
  const tomorrow = addDays(today, 1);
  if (dateStr === today) return 'Today';
  if (dateStr === tomorrow) return 'Tomorrow';
  return d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}

// ── STATUS / BADGES ─────────────────────────────────────────
const STATUS_LABELS = {
  pending:   ['badge-pending',   'Pending'],
  approved:  ['badge-approved',  'Approved'],
  rejected:  ['badge-rejected',  'Rejected'],
  cancelled: ['badge-cancelled', 'Cancelled'],
  completed: ['badge-completed', 'Completed'],
};
export function statusBadge(status, variant = '') {
  const [cls, label] = STATUS_LABELS[status] || ['badge-cancelled', status];
  return `<span class="badge ${cls}">${label}${variant}</span>`;
}

// ── OCCUPANCY COLOR ─────────────────────────────────────────
export const pctColor = p => p < 50 ? 'var(--success)' : p < 80 ? 'var(--warn)' : 'var(--danger)';

// ── TEXT HELPERS ────────────────────────────────────────────
export function initials(name) {
  return (name || '?').trim().split(/\s+/).map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

export function timeAgo(ts) {
  if (!ts) return '';
  const d = Math.floor((Date.now() - new Date(ts)) / 1000);
  if (d < 60)    return 'just now';
  if (d < 3600)  return Math.floor(d / 60) + 'm ago';
  if (d < 86400) return Math.floor(d / 3600) + 'h ago';
  return Math.floor(d / 86400) + 'd ago';
}

export function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
}

// ── TOAST ───────────────────────────────────────────────────
let toastTimer;
export function showToast(msg, type = 'ok') {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.className = `toast ${type}`;
  // force reflow so animation retriggers
  void t.offsetWidth;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 4000);
}

// ── DEBOUNCE ────────────────────────────────────────────────
export function debounce(fn, ms = 250) {
  let h;
  return (...args) => { clearTimeout(h); h = setTimeout(() => fn(...args), ms); };
}

// ── THEME TOGGLE ────────────────────────────────────────────
const THEME_KEY = 'univen-theme';

export function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
  return theme;
}

export function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme') || 'light';
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  try { localStorage.setItem(THEME_KEY, next); } catch {}
  updateThemeIcon();
  return next;
}

const SUN_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>`;
const MOON_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;

export function updateThemeIcon() {
  const btn = document.getElementById('themeBtn');
  if (!btn) return;
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  btn.innerHTML = isDark ? SUN_ICON : MOON_ICON;
  btn.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
  btn.title = isDark ? 'Light mode' : 'Dark mode';
}

export function wireThemeToggle() {
  const btn = document.getElementById('themeBtn');
  if (!btn) return;
  updateThemeIcon();
  btn.addEventListener('click', toggleTheme);
}

// Apply theme ASAP so there's no flash
initTheme();
