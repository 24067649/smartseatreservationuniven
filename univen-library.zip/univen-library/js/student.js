// ============================================================
//  student.js — Student portal (revamped)
// ============================================================
import { NOTIFY_FN_URL, ADMIN_URL } from './config.js';
import {
  sb, todayStr, addDays, formatDateFriendly,
  statusBadge, pctColor,
  showToast, escapeHtml, wireThemeToggle,
} from './utils.js';

// ── STATE ─────────────────────────────────────────────────────
const state = {
  user: null,
  profile: null,
  zones: [],
  selZoneId: null,
  selSeatId: null,
  selSeatNum: null,
  rtSub: null,
};

const $  = id => document.getElementById(id);
const $$ = sel => document.querySelectorAll(sel);
const dateEl = () => $('bookDate');
const selDate = () => dateEl()?.value || todayStr();

// ── BOOT ──────────────────────────────────────────────────────
wireThemeToggle();

(async function boot() {
  try {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) { window.location.href = 'index.html'; return; }
    state.user = session.user;

    // Profile (don't abort boot if this fails — fall back to email)
    const { data: p, error: pErr } = await sb.from('profiles').select('*').eq('id', state.user.id).single();
    if (pErr && pErr.code !== 'PGRST116') console.warn('[boot] profile fetch:', pErr);
    state.profile = p || null;

    if (p?.role === 'admin') { window.location.href = 'admin.html'; return; }

    $('navName').textContent = p?.full_name || state.user.email || 'Student';
    if (p?.student_number) $('bookSnum').value = p.student_number;
    dateEl().value = todayStr();
    dateEl().min   = todayStr();

    await loadZones();
    await loadMyBookings();
    setupRealtime();
  } catch (err) {
    console.error('[boot] failed:', err);
    showToast('Could not load data — check console & Supabase connection.', 'err');
    // Render empty states so the user isn't stuck watching spinners forever
    $('zonesGrid').innerHTML = emptyHTML('Connection error', 'Could not load zones. Check DevTools console.');
    $('myBookingsList').innerHTML = emptyHTML('Connection error', 'Could not load your requests.');
  }
})();

// Watch for sign-outs from elsewhere (e.g. other tab, expired token)
sb.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_OUT' || (!session && event !== 'INITIAL_SESSION')) {
    window.location.href = 'index.html';
  }
});

function emptyHTML(title, sub) {
  return `<div class="empty"><div class="empty-icon">⚠</div><strong>${title}</strong><div style="margin-top:4px;font-size:.78rem">${sub}</div></div>`;
}

$('logoutBtn').addEventListener('click', async () => {
  if (state.rtSub) sb.removeChannel(state.rtSub);
  await sb.auth.signOut();
  window.location.href = 'index.html';
});

// ── DATA LOADING ──────────────────────────────────────────────
async function loadZones(date) {
  const d = date || selDate();

  try {
    const [zRes, sRes, bRes] = await Promise.all([
      sb.from('zones').select('*').eq('is_active', true).order('name'),
      sb.from('seats').select('*').order('seat_number'),
      sb.from('bookings').select('seat_id,status').eq('booking_date', d).in('status', ['pending', 'approved']),
    ]);

    if (zRes.error) console.warn('[zones]', zRes.error);
    if (sRes.error) console.warn('[seats]', sRes.error);
    if (bRes.error) console.warn('[bookings]', bRes.error);

    const zRows = zRes.data || [];
    const sRows = sRes.data || [];
    const bRows = bRes.data || [];

    const booked = {};
    bRows.forEach(b => { booked[b.seat_id] = b.status; });

    state.zones = zRows.map(z => ({
      ...z,
      seats: sRows
        .filter(s => s.zone_id === z.id)
        .map(s => ({ ...s, status: booked[s.id] || 'available' })),
      occupied: sRows.filter(s => s.zone_id === z.id && booked[s.id]).length,
    }));
  } catch (err) {
    console.error('[loadZones]', err);
    showToast('Failed to load zones', 'err');
    state.zones = [];
  }

  renderZones();
  renderOcc();
  renderKpis();
  populateZoneSelect();
  if (state.selZoneId) renderSeatMap(state.selZoneId);
}

// ── RENDERERS ─────────────────────────────────────────────────
function renderKpis() {
  const total = state.zones.reduce((s, z) => s + z.total_seats, 0);
  const occ   = state.zones.reduce((s, z) => s + z.occupied, 0);
  $('kpiAvail').textContent = total - occ;
  $('kpiOcc').textContent   = occ;
  $('kpiTotal').textContent = total;
}

function renderZones() {
  const g = $('zonesGrid');
  if (!state.zones.length) {
    g.innerHTML = `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">📐</div>No zones configured yet.<div style="margin-top:4px;font-size:.78rem">Ask an admin to run the SQL schema or add a zone.</div></div>`;
    return;
  }
  g.innerHTML = state.zones.map(z => {
    const pct = Math.round((z.occupied / z.total_seats) * 100);
    const free = z.total_seats - z.occupied;
    return `
      <button type="button" class="zone-tile ${state.selZoneId === z.id ? 'sel' : ''}" data-action="select-zone" data-zone-id="${z.id}">
        <div class="zone-tile-name">${escapeHtml(z.name)}</div>
        <div class="zone-tile-sub">${escapeHtml(z.label)} · ${free}/${z.total_seats} free</div>
        <div class="prog"><div class="prog-fill" style="width:${pct}%;background:${pctColor(pct)}"></div></div>
      </button>`;
  }).join('');
}

function renderOcc() {
  const el = $('occBars');
  if (!el) return;
  el.innerHTML = state.zones.map(z => {
    const pct = Math.round((z.occupied / z.total_seats) * 100);
    return `
      <div class="occ-row">
        <div class="occ-name">${escapeHtml(z.name)}</div>
        <div class="occ-bar"><div class="occ-fill" style="width:${pct}%;background:${pctColor(pct)}"></div></div>
        <div class="occ-pct">${pct}%</div>
      </div>`;
  }).join('');
}

function renderSeatMap(zoneId) {
  const z = state.zones.find(z => z.id === zoneId);
  if (!z) return;
  $('seatMapTitle').innerHTML = `${escapeHtml(z.name)} <small>${escapeHtml(z.label)}</small>`;
  const grid = $('seatGrid');
  grid.innerHTML = z.seats.map(s => {
    const isSel = state.selSeatId === s.id;
    const st = s.status === 'available' ? 'available' : s.status;
    const cls = `seat ${st}${isSel ? ' sel' : ''}`;
    const clickable = st === 'available';
    return `<button type="button" class="${cls}" data-action="${clickable ? 'pick-seat' : ''}"
              data-zone-id="${z.id}" data-seat-id="${s.id}" data-seat-num="${s.seat_number}"
              title="Seat ${s.seat_number} · ${st}" ${clickable ? '' : 'disabled'}>${s.seat_number}</button>`;
  }).join('');
}

function populateZoneSelect() {
  const sel = $('bookZoneSelect');
  const cur = sel.value;
  sel.innerHTML = state.zones.map(z =>
    `<option value="${z.id}">${escapeHtml(z.name)} — ${escapeHtml(z.label)}</option>`
  ).join('');
  if (cur) sel.value = cur;
  populateSeatSelect();
}

function populateSeatSelect(preselectId) {
  const z = state.zones.find(z => z.id === $('bookZoneSelect').value);
  const sel = $('bookSeatSelect');
  if (!z) return;
  sel.innerHTML = z.seats.map(s => {
    const taken = s.status !== 'available';
    return `<option value="${s.id}" ${taken ? 'disabled' : ''} ${preselectId === s.id ? 'selected' : ''}>${taken ? '✕ ' : ''}Seat ${s.seat_number}${taken ? ' (taken)' : ''}</option>`;
  }).join('');
}

function updateSelBox() {
  const el = $('selBox');
  if (state.selZoneId && state.selSeatNum) {
    const z = state.zones.find(z => z.id === state.selZoneId);
    el.innerHTML = `<strong>Selected:</strong> ${escapeHtml(z?.name || '')} · Seat ${state.selSeatNum}`;
    el.classList.add('has-selection');
  } else {
    el.textContent = 'No seat selected. Click a seat on the map or choose from dropdowns.';
    el.classList.remove('has-selection');
  }
}

// ── INTERACTIONS ──────────────────────────────────────────────
function selectZone(id) {
  state.selZoneId  = id;
  state.selSeatId  = null;
  state.selSeatNum = null;
  renderZones();
  renderSeatMap(id);
  $('bookZoneSelect').value = id;
  populateSeatSelect();
  updateSelBox();
}

function pickSeat(zoneId, seatId, seatNum) {
  state.selZoneId  = zoneId;
  state.selSeatId  = seatId;
  state.selSeatNum = Number(seatNum);
  renderZones();
  renderSeatMap(zoneId);
  $('bookZoneSelect').value = zoneId;
  populateSeatSelect(seatId);
  updateSelBox();
}

// Event delegation for zones + seat map
document.addEventListener('click', e => {
  const t = e.target.closest('[data-action]');
  if (!t) return;
  const a = t.dataset.action;
  if (a === 'select-zone') selectZone(t.dataset.zoneId);
  if (a === 'pick-seat')   pickSeat(t.dataset.zoneId, t.dataset.seatId, t.dataset.seatNum);
  if (a === 'cancel-request') cancelRequest(t.dataset.id);
});

$('bookZoneSelect').addEventListener('change', e => {
  selectZone(e.target.value);
});

$('bookSeatSelect').addEventListener('change', e => {
  const z = state.zones.find(z => z.id === $('bookZoneSelect').value);
  const s = z?.seats.find(s => s.id === e.target.value);
  if (s) {
    state.selSeatId  = s.id;
    state.selSeatNum = s.seat_number;
    updateSelBox();
    if (state.selZoneId) renderSeatMap(state.selZoneId);
  }
});

// Date nav
dateEl().addEventListener('change', async function () {
  state.selSeatId = null;
  state.selSeatNum = null;
  await loadZones(this.value);
  updateSelBox();
});

$('dayPrev').addEventListener('click', () => {
  const today = todayStr();
  const cur = selDate();
  if (cur <= today) { showToast("Can't book in the past.", 'warn'); return; }
  dateEl().value = addDays(cur, -1);
  dateEl().dispatchEvent(new Event('change'));
});

$('dayNext').addEventListener('click', () => {
  dateEl().value = addDays(selDate(), 1);
  dateEl().dispatchEvent(new Event('change'));
});

// Quick-book: pick first available seat in first zone that has one
$('quickBook').addEventListener('click', () => {
  for (const z of state.zones) {
    const seat = z.seats.find(s => s.status === 'available');
    if (seat) {
      pickSeat(z.id, seat.id, seat.seat_number);
      showToast(`Selected ${z.name} · Seat ${seat.seat_number}`, 'ok');
      return;
    }
  }
  showToast('No seats available — try another date.', 'warn');
});

// ── MODAL ─────────────────────────────────────────────────────
const modal = $('bookModal');
function openModal()  { modal.classList.add('show'); }
function closeModal() { modal.classList.remove('show'); }

modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
$('cancelModal').addEventListener('click', closeModal);
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && modal.classList.contains('show')) closeModal();
});

$('openBookModal').addEventListener('click', () => {
  const snum = $('bookSnum').value.trim();
  if (!snum)            return showToast('Please enter your student number', 'warn');
  if (!state.selSeatId) return showToast('Please select a seat', 'warn');

  const z = state.zones.find(z => z.id === state.selZoneId);
  $('confSnum').textContent = snum;
  $('confZone').textContent = `${z?.name} — ${z?.label}`;
  $('confSeat').textContent = `Seat ${state.selSeatNum}`;
  $('confDate').textContent = formatDateFriendly(selDate()) + ' · ' + selDate();
  $('confTime').textContent = `${$('bookTime').value} · ${$('bookDur').value}h`;
  openModal();
});

$('confirmBookingBtn').addEventListener('click', async () => {
  const btn = $('confirmBookingBtn');
  btn.disabled = true;
  btn.textContent = 'Submitting…';

  // Race-safe conflict check
  const { data: clash } = await sb.from('bookings').select('id')
    .eq('seat_id', state.selSeatId)
    .eq('booking_date', selDate())
    .in('status', ['pending', 'approved']);

  if (clash?.length) {
    showToast('That seat was just taken — please pick another.', 'err');
    btn.disabled = false;
    btn.textContent = 'Submit request';
    closeModal();
    await loadZones(selDate());
    return;
  }

  const snum = $('bookSnum').value.trim();
  const z    = state.zones.find(z => z.id === state.selZoneId);
  const startTime = $('bookTime').value + ':00';
  const dur  = +$('bookDur').value;

  const { error } = await sb.from('bookings').insert({
    user_id:        state.user.id,
    seat_id:        state.selSeatId,
    booking_date:   selDate(),
    start_time:     startTime,
    duration_hours: dur,
    student_number: snum,
    status:         'pending',
  });

  if (error) {
    showToast(error.message, 'err');
    btn.disabled = false;
    btn.textContent = 'Submit request';
    return;
  }

  // Sync student number into profile
  if (snum !== state.profile?.student_number) {
    await sb.from('profiles').update({ student_number: snum }).eq('id', state.user.id);
    if (state.profile) state.profile.student_number = snum;
  }

  // Fire-and-forget email to admin
  if (NOTIFY_FN_URL) {
    fetch(NOTIFY_FN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'new_request',
        booking: {
          student_name:   state.profile?.full_name || state.user.email,
          student_number: snum,
          zone_name:      `${z?.name} — ${z?.label}`,
          seat_number:    state.selSeatNum,
          booking_date:   selDate(),
          start_time:     $('bookTime').value,
          duration_hours: dur,
          admin_url:      ADMIN_URL,
        },
      }),
    }).catch(() => {});
  }

  closeModal();
  showToast('Request submitted — waiting for admin approval.', 'ok');
  state.selSeatId  = null;
  state.selSeatNum = null;
  updateSelBox();
  btn.disabled = false;
  btn.textContent = 'Submit request';
});

// ── MY BOOKINGS ───────────────────────────────────────────────
async function loadMyBookings() {
  try {
    const { data, error } = await sb.from('bookings')
      .select('*, seat:seats(seat_number, zone:zones(name,label))')
      .eq('user_id', state.user.id)
      .order('created_at', { ascending: false });
    if (error) console.warn('[myBookings]', error);
    renderMyBookings(data || []);
  } catch (err) {
    console.error('[loadMyBookings]', err);
    $('myBookingsList').innerHTML = emptyHTML('Connection error', 'Could not load your requests.');
  }
}

function renderMyBookings(rows) {
  const el = $('myBookingsList');
  if (!rows.length) {
    el.innerHTML = `<div class="empty"><div class="empty-icon">📋</div>No requests yet. Choose a seat and submit your first request.</div>`;
    return;
  }
  el.innerHTML = rows.map(b => `
    <div class="booking-row">
      <div class="br-main">
        <h4>${escapeHtml(b.seat?.zone?.name || '—')} · Seat ${b.seat?.seat_number ?? '—'}</h4>
        <p>${formatDateFriendly(b.booking_date)} · ${b.start_time?.slice(0,5)} · ${b.duration_hours}h</p>
        ${b.admin_note ? `<div class="br-note">Admin note: ${escapeHtml(b.admin_note)}</div>` : ''}
      </div>
      <div class="br-right">
        ${statusBadge(b.status)}
        ${b.status === 'pending' ? `<button class="btn btn-danger btn-sm" data-action="cancel-request" data-id="${b.id}">Cancel</button>` : ''}
      </div>
    </div>`).join('');
}

async function cancelRequest(id) {
  if (!confirm('Cancel this request?')) return;
  await sb.from('bookings').update({ status: 'cancelled' }).eq('id', id).eq('user_id', state.user.id);
  showToast('Request cancelled', 'ok');
}

// ── REALTIME ──────────────────────────────────────────────────
function setupRealtime() {
  state.rtSub = sb.channel('student-rt')
    .on('postgres_changes',
      { event: '*', schema: 'public', table: 'bookings', filter: `user_id=eq.${state.user.id}` },
      async (payload) => {
        if (payload.eventType === 'UPDATE') {
          const b = payload.new;
          if (b.status === 'approved') showToast('✓ Your booking was approved!', 'ok');
          if (b.status === 'rejected') showToast(`✕ Booking rejected${b.admin_note ? ': ' + b.admin_note : ''}`, 'err');
        }
        await loadMyBookings();
        await loadZones(selDate());
      })
    .on('postgres_changes',
      { event: '*', schema: 'public', table: 'bookings' },
      async () => { await loadZones(selDate()); })
    .subscribe();
}
