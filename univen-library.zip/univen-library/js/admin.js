import { sb } from './utils.js';

const $ = id => document.getElementById(id);

/* =========================================================
   AUTH CHECK
========================================================= */
const {
  data: { session }
} = await sb.auth.getSession();

if (!session) {
  window.location.href = 'index.html';
}

$('navName').textContent =
  session.user.user_metadata?.full_name || 'Admin';

/* =========================================================
   SIGN OUT
========================================================= */
$('logoutBtn').addEventListener('click', async () => {
  await sb.auth.signOut();

  // Redirect back to login page
  window.location.href = 'index.html';
});

/* =========================================================
   THEME TOGGLE
========================================================= */
const themeBtn = $('themeBtn');

function updateThemeIcon() {
  const theme =
    document.documentElement.getAttribute('data-theme');

  themeBtn.innerHTML =
    theme === 'dark'
      ? '☀️'
      : '🌙';
}

updateThemeIcon();

themeBtn.addEventListener('click', () => {
  const current =
    document.documentElement.getAttribute('data-theme');

  const next = current === 'dark' ? 'light' : 'dark';

  document.documentElement.setAttribute(
    'data-theme',
    next
  );

  localStorage.setItem('univen-theme', next);

  updateThemeIcon();
});

/* =========================================================
   TABS
========================================================= */
document.querySelectorAll('.sub-tab').forEach(tab => {
  tab.addEventListener('click', () => {

    document
      .querySelectorAll('.sub-tab')
      .forEach(t => t.classList.remove('active'));

    tab.classList.add('active');

    document
      .querySelectorAll('section[id^="tab-"]')
      .forEach(sec => sec.hidden = true);

    $('tab-' + tab.dataset.tab).hidden = false;
  });
});

/* =========================================================
   LOAD BOOKINGS
========================================================= */
async function loadBookings() {

  const { data, error } = await sb
    .from('bookings')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.log(error);
    return;
  }

  renderPending(data);
  renderAllBookings(data);
  updateStats(data);
}

/* =========================================================
   PENDING REQUESTS
========================================================= */
function renderPending(bookings) {

  const pending = bookings.filter(
    b => b.status === 'pending'
  );

  const container = $('pendingList');

  $('pendingCnt').style.display =
    pending.length ? 'inline-flex' : 'none';

  $('pendingCnt').textContent = pending.length;

  if (!pending.length) {
    container.innerHTML = `
      <div class="empty">
        No pending requests
      </div>
    `;
    return;
  }

  container.innerHTML = pending.map(b => `
    <div class="request-card">

      <div class="req-header">
        <div class="req-avatar">
          ${b.student_name?.charAt(0) || 'S'}
        </div>

        <div>
          <div class="req-name">
            ${b.student_name || 'Student'}
          </div>

          <div class="req-meta">
            ${b.student_number || ''}
          </div>
        </div>
      </div>

      <div class="req-details">

        <div class="req-detail-item">
          <span class="req-detail-label">Zone</span>
          <div class="req-detail-val">
            ${b.zone}
          </div>
        </div>

        <div class="req-detail-item">
          <span class="req-detail-label">Seat</span>
          <div class="req-detail-val">
            ${b.seat}
          </div>
        </div>

        <div class="req-detail-item">
          <span class="req-detail-label">Date</span>
          <div class="req-detail-val">
            ${b.booking_date}
          </div>
        </div>

        <div class="req-detail-item">
          <span class="req-detail-label">Time</span>
          <div class="req-detail-val">
            ${b.time_slot}
          </div>
        </div>

      </div>

      <div class="req-actions">
        <button class="btn btn-approve"
          onclick="approveBooking('${b.id}')">
          Approve
        </button>

        <button class="btn btn-reject"
          onclick="rejectBooking('${b.id}')">
          Reject
        </button>
      </div>

    </div>
  `).join('');
}

/* =========================================================
   APPROVE BOOKING
========================================================= */
window.approveBooking = async function(id) {

  await sb
    .from('bookings')
    .update({
      status: 'approved'
    })
    .eq('id', id);

  loadBookings();
};

/* =========================================================
   REJECT BOOKING
========================================================= */
window.rejectBooking = async function(id) {

  await sb
    .from('bookings')
    .update({
      status: 'rejected'
    })
    .eq('id', id);

  loadBookings();
};

/* =========================================================
   ALL BOOKINGS TABLE
========================================================= */
function renderAllBookings(bookings) {

  const tbody = $('bookingsTbody');

  tbody.innerHTML = bookings.map(b => `
    <tr>
      <td>${b.id}</td>
      <td>${b.student_name || ''}</td>
      <td>${b.zone}</td>
      <td>${b.seat}</td>
      <td>${b.booking_date}</td>
      <td>${b.time_slot}</td>

      <td>
        <span class="badge badge-${b.status}">
          ${b.status}
        </span>
      </td>

      <td>
        —
      </td>
    </tr>
  `).join('');
}

/* =========================================================
   DASHBOARD STATS
========================================================= */
function updateStats(bookings) {

  const pending =
    bookings.filter(b => b.status === 'pending').length;

  const approved =
    bookings.filter(b => b.status === 'approved').length;

  const rejected =
    bookings.filter(b => b.status === 'rejected').length;

  $('adPending').textContent = pending;
  $('adOcc').textContent = approved;
  $('adAvail').textContent =
    Math.max(0, 200 - approved);

  $('adToday').textContent = bookings.length;
}

/* =========================================================
   REALTIME BOOKINGS
========================================================= */
sb.channel('bookings-realtime')
  .on(
    'postgres_changes',
    {
      event: '*',
      schema: 'public',
      table: 'bookings'
    },
    () => {
      loadBookings();
    }
  )
  .subscribe();

/* =========================================================
   INITIAL LOAD
========================================================= */
loadBookings();