// ── Replace with your Supabase project details ──────────────
// Dashboard → Project Settings → API
export const SUPABASE_URL  = 'https://sgvggpddlsjsitnifrnj.supabase.co';
export const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNndmdncGRkbHNqc2l0bmlmcm5qIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwNjY3NzEsImV4cCI6MjA5MTY0Mjc3MX0.twZx_YbFHH7l9dE6fFijYMqkkIbdf_GjnCWROu5Bm_c';

// URL of your deployed Edge Function (leave blank to skip emails)
// After deploying: supabase functions deploy notify-booking
// Then paste the URL shown, e.g. https://xxxx.supabase.co/functions/v1/notify-booking
export const NOTIFY_FN_URL = '';

// Admin page URL — used in notification emails
export const ADMIN_URL = 'http://localhost:3000/admin.html';
